WorkDays Outlook Agent - Worker Model Fix
=========================================

Purpose
-------
This update changes the Outlook Agent architecture so the resident tray agent no longer keeps Outlook COM/MAPI objects alive after a sync.

Before this update, the resident agent stayed open all day and also performed the Outlook calendar sync. If Outlook COM references, calendar Items collections, Restrict results, EntryIDs, or item objects stayed alive, Outlook could become slow when opening the Calendar after synchronization.

New architecture
----------------
The same executable now has two modes:

1. Resident launcher mode
   Workdays_Outlook_Agent.exe
   - Runs in the tray.
   - Watches the periodic timer and WorkDays Sync requests.
   - Does not execute Outlook calendar COM operations directly.
   - Starts a temporary worker process when a sync is needed.

2. Short-lived worker mode
   Workdays_Outlook_Agent.exe /syncworker
   - Connects to Outlook.
   - Reads the calendar.
   - Builds and validates the sync plan.
   - Creates backups and applies changes when safe.
   - Updates the state database and registry status.
   - Exits completely when finished.

When the worker exits, Windows releases the Outlook COM/MAPI references held by that process. This should reduce or eliminate the Outlook Calendar slowness seen after sync.

Cleanup worker
--------------
Outlook cleanup also runs through a short-lived worker:

   Workdays_Outlook_Agent.exe /cleanworker

The legacy command remains supported:

   Workdays_Outlook_Agent.exe /cleanoutlook

Worker status
-------------
The worker writes status into:

   HKEY_CURRENT_USER\Software\WorkDays\OutlookAgent

Keys include:

   Worker_Status
   Worker_Message
   Worker_UpdatedAt
   Worker_PID
   Worker_ExitCode
   Worker_Changes
   Worker_DeletedItems

State database
--------------
The synchronization state database is:

   Workdays_Outlook_Agent_State.db

The legacy file is still migrated/deleted defensively:

   Workdays_Outlook_Agent_State.ini

WorkDays settings cleanup behavior
----------------------------------
In Settings > Outlook Agent, when Clean Outlook WorkDays items is confirmed:

- the settings window is disabled while the cleanup runs;
- the status label shows that cleanup is running;
- controls are enabled again after cleanup finishes or fails;
- both the .db state file and any legacy .ini file are deleted as cleanup fallback.

Build order
-----------
1. Put Workdays_Backup.au3 in the same folder as the source files.
2. Compile Workdays_Outlook_Agent.au3 as:

   Workdays_Outlook_Agent.exe

3. Compile Workdays.au3 after the agent executable exists, because WorkDays embeds it using FileInstall.

Versions
--------
Agent: 1.0.1.6
WorkDays: 2.1.4.18

Notes
-----
This environment cannot compile or execute AutoIt/Outlook COM. The files were patched and statically checked for Func/EndFunc balance.
