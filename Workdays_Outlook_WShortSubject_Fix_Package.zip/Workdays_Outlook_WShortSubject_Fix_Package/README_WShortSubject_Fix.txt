WorkDays Outlook Agent - W shortcut subject fix

Issue fixed
-----------
An all-day Outlook appointment created manually with subject like:

  W - Remote

was not being imported into WorkDays because the agent only treated these formats as WorkDays candidates:

  WorkDays - Remote
  WorkDays - R
  [WD:R]
  Outlook categories like WorkDays - Remote

What changed
------------
The agent now recognizes the short manual Outlook subject formats below:

  W - Remote
  W: Remote
  WD - Remote
  WD: Remote
  WorkDay - Remote
  WorkDays - Remote

The same pattern works for all WorkDays day types:

  On Site / O
  Remote / R
  Holiday / H
  PTO / P
  Travel / T
  Sick / S
  Blank / B
  Weekend / W

Examples:

  W - On Site
  W - Remote
  W - Travel
  W - PTO
  W - Holiday
  W - Sick
  WD - R
  [WD:R]

Important setting
-----------------
In WorkDays > Settings > Outlook Agent, keep this option unchecked if you want to create or edit days directly in Outlook:

  Only read items created by the agent

If that option is checked, manually created Outlook items are ignored by design.

Build order
-----------
1. Compile Workdays_Outlook_Agent.au3 as:
   E:\GitHub\WorkDays\Workdays_Outlook_Agent.exe

2. Compile Workdays.au3.
   WorkDays will embed the latest compiled agent via FileInstall / AutoIt3Wrapper resource.
