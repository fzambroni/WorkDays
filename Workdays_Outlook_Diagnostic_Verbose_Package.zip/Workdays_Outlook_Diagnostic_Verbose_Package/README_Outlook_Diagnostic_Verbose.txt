WorkDays Outlook Agent - Diagnostic Verbose Build
=================================================

Purpose
-------
This build adds a much more detailed verbose log to diagnose why Outlook-created all-day events such as:

  W - On Site
  W - Remote
  WD - PTO
  WorkDays - Travel
  [WD:O]
  [WD:R]

are not being pulled into WorkDays.

What changed
------------
1. The agent now logs the full sync configuration at the start of every sync.
2. The agent logs the default Outlook calendar folder used by the sync.
3. The agent logs the exact Outlook Restrict filter.
4. The agent logs each Outlook item found in the restricted range, including:
   - item number
   - message class
   - subject
   - normalized subject
   - start and end values as returned by Outlook
   - all-day flag
   - busy/free status
   - categories
   - WorkDays user properties
   - shortened EntryID
5. For each item, the agent logs why it was accepted or rejected as a WorkDays candidate.
6. For accepted items, the agent logs:
   - date conversion logic
   - MDY vs DMY candidates when the Outlook date is ambiguous
   - status parsed from category
   - status parsed from subject
   - status parsed from WorkDays user property
   - final chosen status
7. The agent logs registry writes and read-back verification.
8. The agent logs state file updates.
9. The agent still writes the log in the same folder as the executable:

   Workdays_Outlook_Agent.log

Potential fix included
----------------------
This build also improves Outlook date conversion. If Outlook returns an ambiguous local date such as 02/07/2026, the agent now tests both:

  MDY -> 2026-02-07
  DMY -> 2026-07-02

and chooses the candidate that falls inside the active sync range. This is important because a July 2 all-day event can otherwise be interpreted as February 7 on systems using day/month/year date formatting.

How to use
----------
1. Compile Workdays_Outlook_Agent.au3 as:

   E:\GitHub\WorkDays\Workdays_Outlook_Agent.exe

2. Compile Workdays.au3.
3. Open WorkDays > Settings > Outlook Agent.
4. Enable:

   Verbose diagnostic log

5. Confirm this is disabled unless you intentionally want managed-only sync:

   Only read items created by the agent

6. Click Save.
7. Click Install / Update to install the embedded agent.
8. Start the agent and run Sync now.
9. Open the log from WorkDays or directly from the agent folder:

   %LOCALAPPDATA%\WorkDays\Workdays_Outlook_Agent.log

How to read the log
-------------------
Search for the subject you created, for example:

  W - On Site

If the subject does not appear at all:
- The item is probably not in the default Outlook calendar being scanned.
- Or the item is outside the configured Past/Future range.
- Or the Outlook Restrict filter is not returning it.

If the item appears but says rejected:
- Read the rejection reason on the same line. It will usually say whether ManagedOnly is enabled or the subject/category was not recognized.

If the item appears and is mapped:
- Look for a line like:

  mapped: date=2026-07-02 status=O

If the mapped date is wrong:
- Look at the date parser lines. They will show MDY and DMY candidates.
- You can force DMY by setting this registry value if needed:

  HKEY_CURRENT_USER\Software\WorkDays\OutlookAgent
  Outlook_DateOrder = DMY

If the item is mapped but still not visible in WorkDays:
- Look for Registry write OK lines.
- The expected registry path for July 2, 2026 is:

  HKEY_CURRENT_USER\Software\WorkDays\2026\07
  02 = O

Build notes
-----------
The agent settings are still owned by WorkDays and stored under:

  HKEY_CURRENT_USER\Software\WorkDays\OutlookAgent

The .ini file remains only for internal sync state, not user settings.
